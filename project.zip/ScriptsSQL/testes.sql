/*
insert into pessoas
values(UUID(), 'A', 'A@', 'Aluno');

insert into discentes
values('123', '375024c0-c2da-11f0-9802-d843aebd54b9');

delete from pessoas where pessoas.UUID = '375024c0-c2da-11f0-9802-d843aebd54b9';

select * from discentes;

*/

-- call insertDocente(UUID(), 'A', 'A@');

-- call insertDisciplina(UUID(),'Mat','A');

-- select UUID from pessoas;


-- set @Nome_professor = 'A';
-- select UUID from pessoas where pessoas.Nome = @Nome_professor and pessoas.Vinculo_UNESP = 'Docente';

select * from disciplinas;

