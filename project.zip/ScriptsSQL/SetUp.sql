call insertDiscente(UUID(), 'Abigail Sayury Nakashima', 'abigail.s.nakashima@unesp.br', 231254318);
call insertDiscente(UUID(), 'Miguel de Campos Rodrigues Moret', 'miguel.moret@unesp.br', 231254806);
call insertDiscente(UUID(), 'Cristian Eidi Yoshimura', 'cristian.eidi@unesp.br', 231255233);
call insertDiscente(UUID(), 'Daniel Amorim Andrade de Pádua', 'daniel.aa.padua@unesp.br', 231255373);
call insertDiscente(UUID(), 'Paulo Sergio Campos de Lima', 'paulo.sc.lima@unesp.br', 231254466);
call insertDiscente(UUID(), 'Filipe Augusto Nava De Almeida Pupo', 'filipe.nava@unesp.br', 211255467);
call insertDiscente(UUID(), 'Arthur Koichi Nakao', 'arthur.koichi@unesp.br', 231254661);

call insertChapa(UUID(),'Grace Hopper');

call insertMembroNome('Abigail Sayury Nakashima', 'Presidente','Grace Hopper');
call insertMembroNome('Miguel de Campos Rodrigues Moret', 'Vice-presidente','Grace Hopper');
call insertMembroNome('Cristian Eidi Yoshimura', 'Diretor de comunicação','Grace Hopper');
call insertMembroNome('Daniel Amorim Andrade de Pádua', 'Diretor de evento','Grace Hopper');
call insertMembroNome('Paulo Sergio Campos de Lima', 'Diretor de finança','Grace Hopper');
call insertMembroNome('Filipe Augusto Nava De Almeida Pupo', 'Diretor de relações públicas','Grace Hopper');