/*drop trigger if exists logInsertChapa;
drop trigger if exists logInsertCertificado;

drop table if exists Provas;
drop table if exists Cursando;
drop table if exists Sugestoes;
drop table if exists Votos;
drop table if exists Logger;
drop table if exists Pautas;
drop table if exists Membros;
drop table if exists Inscritos;
drop table if exists Discentes;
drop table if exists Certificados;
drop table if exists Disciplinas;
drop table if exists Eventos;
drop table if exists Chapas;
drop table if exists Pessoas;*/
drop database if exists db;