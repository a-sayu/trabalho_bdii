# Trabalho de Banco de Dados II

Feito por Abigail Sayury Nakashima e Arthur Koichi Nakao.

## Estrutura de Pastas

src/
---lib/
------assets/
---------favicon.svg
---------logo-cacic.svg
---------menu.png
---------profile.png
------components/
---------CalendarMonth.svelte
---------CalendarWeek.svelte
---------NavBar.svelte
------server/
---------db.ts
------index.ts
---routes/
------about-page/
---------+page.svelte
---------+page.server.ts
------adicionar-eventos/
---------+page.svelte
---------+page.server.ts
------adicionar-provas/
---------+page.svelte
---------+page.server.ts
------autorizar-evento/
---------+page.svelte
---------+page.server.ts
------emitir-certificado/
---------+page.svelte
---------+page.server.ts
------gerar-qrcode/
---------+page.svelte
---------+page.server.ts
------gerenciar-pessoas/
---------+page.svelte
---------+page.server.ts
------log-page/
---------+page.svelte
---------+page.server.ts
------login/
---------+page.svelte
---------+page.server.ts
------profile/
---------+page.svelte
---------+page.server.ts
------registrar-presenca/
---------+page.svelte
---------+page.server.ts
------sugestoes-e-pautas/
---------+page.svelte
---------+page.server.ts
------+page.svelte
------+page.server.ts
------+layout.server.ts
------+layout.svelte
---app.css
---app.d.ts
---app.html
---hooks.server.ts
