
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/about-page" | "/adicionar-eventos" | "/adicionar-provas" | "/autorizar-evento" | "/emitir-certificados" | "/gerar-qrcode" | "/gerenciar-pessoas" | "/log-page" | "/login" | "/profile" | "/profile/editar" | "/registrar-presenca" | "/sugestoes-e-pautas";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/about-page": Record<string, never>;
			"/adicionar-eventos": Record<string, never>;
			"/adicionar-provas": Record<string, never>;
			"/autorizar-evento": Record<string, never>;
			"/emitir-certificados": Record<string, never>;
			"/gerar-qrcode": Record<string, never>;
			"/gerenciar-pessoas": Record<string, never>;
			"/log-page": Record<string, never>;
			"/login": Record<string, never>;
			"/profile": Record<string, never>;
			"/profile/editar": Record<string, never>;
			"/registrar-presenca": Record<string, never>;
			"/sugestoes-e-pautas": Record<string, never>
		};
		Pathname(): "/" | "/about-page" | "/about-page/" | "/adicionar-eventos" | "/adicionar-eventos/" | "/adicionar-provas" | "/adicionar-provas/" | "/autorizar-evento" | "/autorizar-evento/" | "/emitir-certificados" | "/emitir-certificados/" | "/gerar-qrcode" | "/gerar-qrcode/" | "/gerenciar-pessoas" | "/gerenciar-pessoas/" | "/log-page" | "/log-page/" | "/login" | "/login/" | "/profile" | "/profile/" | "/profile/editar" | "/profile/editar/" | "/registrar-presenca" | "/registrar-presenca/" | "/sugestoes-e-pautas" | "/sugestoes-e-pautas/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}