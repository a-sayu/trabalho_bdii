import { query } from "$lib/server/db";
import { fail, type Actions } from "@sveltejs/kit";
import { randomUUID } from "node:crypto";

export const actions: Actions = {
    default: async ({ request }) => {
        const data = await request.formData();

        const Nome_evento = data.get("nome_evento") as string;
        const dataStr = data.get("data") as string;
        const horario = data.get("horario") as string;
        const Responsavel = data.get("responsavel") as string;
        const Descricao = data.get("descricao") as string;

        // 1. Extração de 'maximo' e conversão para número
        const maximoData = data.get("maximo");
        let Maximo_participantes: number;

        // Tenta converter para inteiro, se for string vazia, retorna NaN
        if (typeof maximoData === "string") {
            Maximo_participantes = parseInt(maximoData, 10);
        } else {
            Maximo_participantes = NaN; // Caso o campo nem exista (improvável, mas seguro)
        }

        // 2. Validação completa (Verifica se é número, se é > 0 e se os strings existem)
        if (
            !Nome_evento ||
            !dataStr ||
            !horario ||
            isNaN(Maximo_participantes) ||
            Maximo_participantes <= 0
        ) {
            // Log no terminal para indicar falha de validação do formulário
            console.warn(
                `[EVENTO] Tentativa de adição falhou: Campos obrigatórios ausentes, Maximo: ${Maximo_participantes}.`
            );

            return fail(400, {
                error: "Título, data, horário e Máximo de Participantes (número positivo) são obrigatórios.",
                Nome_evento,
            });
        }

        const UUID_evento = randomUUID();
        let dataISO: string;
        try {
            // 1. Divide a string "24/11/2025" em [24, 11, 2025]
            const [day, month, year] = dataStr.split("/");
            if (!day || !month || !year) {
                throw new Error("Formato de data inesperado");
            }
            // 2. Reverte para o formato ISO: "2025-11-24"
            dataISO = `${year}-${month}-${day}`;
        } catch (e) {
            console.error(`[EVENTO] Erro na conversão de data: ${dataStr}`, e);
            return fail(400, {
                error: "Formato de data inválido.",
                Nome_evento,
            });
        }
        const Data_local_datetime = `${dataISO} ${horario}:00`;

        // Parâmetros na ORDEM exata da SP: (UUID_evento, Nome_evento, Data_local, Maximo, Responsavel, Descricao )
        const spParams = [
            UUID_evento,
            Nome_evento, // Nome_evento
            Data_local_datetime, // Data_local
            Maximo_participantes, // Maximo
            Responsavel,
            Descricao
        ];

        try {
            // Chamada à Stored Procedure
            await query("CALL insertevento(?,?,?,?,?,?)", spParams);

            // Log de sucesso
            console.log(
                `✅ Evento "${Nome_evento}" (UUID: ${UUID_evento.slice(
                    0,
                    8
                )}...) adicionado com sucesso.`
            );

            return { success: true };
        } catch (e) {
            // Log de erro no DB. Usa JSON.stringify para capturar o sqlMessage.
            console.error(
                "❌ Erro no DB ao adicionar evento:",
                JSON.stringify(e, null, 2)
            );

            return fail(500, {
                error: "Erro no servidor ao salvar o evento. Verifique o console do servidor para detalhes do DB.",
                Nome_evento,
            });
        }
    },
};
