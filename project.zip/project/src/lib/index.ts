// place files you want to import through the `$lib` alias in this folder.
"../lib/server/permissions.ts";
"../lib/types.ts";
"../lib/api/remote.ts";