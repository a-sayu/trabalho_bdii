// src/lib/server/permissions.ts

export const ALLOWED_EMAILS: string[] = [
    "cacic.fct@gmail.com"
];

export const ADMIN_EMAILS: string[] = [
    "abigail.s.nakashima@unesp.br",
    "miguel.moret@unesp.br",
    "cristian.eidi@unesp.br",
    "daniel.aa.padua@unesp.br",
    "paulo.sc.lima@unesp.br",
    "filipe.nava@unesp.br",
    "arthur.koichi@unesp.br",
    "cacic.fct@gmail.com",
];

export const ADMIN_ROUTES: string[] = [
    "/autorizar-evento",
    "/gerenciar-pessoas",
    "/log-page",
    "/registrar-presenca",
];

export const PROTECTED_ROUTES: string[] = [
    "/adicionar-eventos",
    "/adicionar-provas",
    "/emitir-certificado",
    "/gerar-qrcode",
    "/sugestoes-e-pautas",
    "/profile",
];